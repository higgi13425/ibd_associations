library(testthat)
library(rebus.base)

test_check("rebus.base")
