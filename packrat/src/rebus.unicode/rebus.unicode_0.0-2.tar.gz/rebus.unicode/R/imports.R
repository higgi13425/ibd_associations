#' @importFrom rebus.base as.regex
#' @importFrom rebus.base regex
#' @importFrom rebus.base repeated
#' @importFrom rebus.base %R%
NULL
