#' @importFrom rebus.base %R%
#' @importFrom rebus.base %|%
#' @importFrom rebus.base as.regex
#' @importFrom rebus.base ascii_digit
#' @importFrom rebus.base case_insensitive
#' @importFrom rebus.base char_range
#' @importFrom rebus.base group
#' @importFrom rebus.base optional
#' @importFrom rebus.base or1
#' @importFrom rebus.base repeated
#' @importFrom rebus.base UNMATCHABLE
#' @importFrom rebus.base engroup
NULL
