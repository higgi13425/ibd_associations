library(testthat)
library(rebus.numbers)

test_check("rebus.numbers")
